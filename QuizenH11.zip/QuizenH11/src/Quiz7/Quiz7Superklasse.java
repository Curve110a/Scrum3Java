package Quiz7;

public class Quiz7Superklasse {
	Quiz7Superklasse(String naam){
		this(naam,"d");
		System.out.println(naam);
	}
	Quiz7Superklasse(String naam, String naam2){
		System.out.println(naam);
		System.out.println(naam2);
	}

}
