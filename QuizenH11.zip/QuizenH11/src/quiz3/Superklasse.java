package quiz3;



public class Superklasse {
	protected char c = 'G';

	void mijnMethode ()
	{
		System.out.print(c);
	}
	Superklasse(){
		System.out.print('Q');
	}
}
