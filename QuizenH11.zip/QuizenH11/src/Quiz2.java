
public class Quiz2 
{
	protected int x = 1;
	Quiz2(){
		x += 2;
	}
}

