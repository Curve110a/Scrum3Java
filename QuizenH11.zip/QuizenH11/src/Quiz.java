
public class Quiz extends Quiz2{
	
	Quiz(int y){
		x +=y;
	}
	
	
	public static void main(String[] args) {
		Quiz sk = new Quiz(4);
		System.out.print(sk.x);
		
		Quiz sk2 = new Quiz(6);
		System.out.print(sk2.x);
	}
}