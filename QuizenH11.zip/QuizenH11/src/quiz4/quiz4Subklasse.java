package quiz4;

public class quiz4Subklasse extends SuperA
{
	int x;

	public quiz4Subklasse()
	{
		x += 2;
		y += 3;
		System.out.print(" x" + x);
		System.out.print(" y" + y);
	}

	public static void main(String[] args) {
		quiz4Subklasse subK = new quiz4Subklasse();
	}

}
