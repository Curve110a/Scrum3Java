
public class Superklasse 
{

	protected int x = 5;
}


