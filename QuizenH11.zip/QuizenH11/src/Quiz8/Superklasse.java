package Quiz8;


public class Superklasse {

	public String str1 = "1";
	protected String str2 = "2";
	String str3 = "3";
	private String str4 = "4";
	protected int mijnInt = 3;
}

