package quiz4;

public class SuperA extends SuperB {
	int y = 7;
	
	public SuperA() {
		y ++;
		System.out.print( " y" + y);
	}

}