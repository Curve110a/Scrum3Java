package Quiz6;

public class Quiz6Subklasse extends Quiz6Superklasse{
	void mijnMethode() {
		char e ='p';
		x ++;
		System.out.print(e);
		super.mijnMethode();
		x += 2;
		System.out.print(x);
	}
	public static void main(String[] args) {
		
		Quiz6Subklasse sk = new Quiz6Subklasse();
		sk.mijnMethode();
	}

}
