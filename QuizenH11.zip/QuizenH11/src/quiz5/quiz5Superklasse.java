package quiz5;

public class quiz5Superklasse 
{
	protected int x = 2;
	
	int mijnMethode(int i) {
		return x + i;
	}

}
