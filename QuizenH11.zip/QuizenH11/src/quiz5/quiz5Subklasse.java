package quiz5;

public class quiz5Subklasse extends quiz5Superklasse
{
	int mijnMethode (int i, int i2) 
	{
		return mijnMethode(i) + super.x + i2;
	}
	public static void main(String[] arg) {
		quiz5Subklasse subK = new quiz5Subklasse();
		System.out.println(subK.mijnMethode(2,8));
	}
}