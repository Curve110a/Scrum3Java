public class Subklasse extends Superklasse
{
	private int y = 8;

	Subklasse()
	{
		x += 2;
		y ++;
		System.out.print(x + "," + y);
	}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Subklasse sk = new Subklasse();

	}

}