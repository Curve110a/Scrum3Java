package Quiz8;


import Quiz8.Superklasse;  
public class Subklasse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Superklasse supK = new Superklasse();
		Subklasse subK = new Subklasse();
		
		System.out.println(supK.str1); /* 1 */
		System.out.println(supK.str2); /* 2 */
		//System.out.println(supK.str3); /* 3 */
		//System.out.println(supK.str4); /* 4 */
		//System.out.println(supK.str2); /* 5 */
	}

}
