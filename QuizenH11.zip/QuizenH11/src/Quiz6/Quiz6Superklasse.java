package Quiz6;

public class Quiz6Superklasse {
	protected int x = 3;
	protected char e = 'd';
	
	void mijnMethode()
	{
		x += 4;
		System.out.print(e);
		System.out.print(x);
	}
}
