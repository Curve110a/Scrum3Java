package Quiz7;

public class Quiz7Subklasse extends Quiz7Superklasse {

	Quiz7Subklasse(String naam){
		super("s");
		System.out.println(naam);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("dit is quiz7 ");
		Quiz7Subklasse sk = new Quiz7Subklasse("X");

	}

}
